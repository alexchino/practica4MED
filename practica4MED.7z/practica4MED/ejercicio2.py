
productos = {
    "manzanas": 2.0,
    "bananas": 1.5,
    "peras": 2.5,
    "uvas": 3.0,
    "naranjas": 1.0,
}

nombre_producto = input("Ingrese el nombre del producto: ").lower() 
cantidad = int(input("Ingrese la cantidad que desea comprar: "))

if nombre_producto in productos:
    precio_unitario = productos[nombre_producto]
    total_pagar = cantidad * precio_unitario
    print("El total a pagar por {} {} es: ${:.2f}".format(cantidad, nombre_producto, total_pagar))
else:
    print("El producto '{}' no se encuentra disponible.".format(nombre_producto))
